<?php  
  
// image to string conversion
$image = file_get_contents('eye.png'); 
//$image1 = file_get_contents('thumnail 3.png');
//$imagelink1 = file_get_contents('eye.png'); 
// image string data into base64 
$encdata = base64_encode($image);
//$encdata1 = base64_encode($image1);
 
//echo  "with using hash image 1 - ",  hash('md5', $image),"\n";
echo  " \n with using hash image 1 - ",  hash('sha1', $image),"\n";

echo "\n $encdata";
    
 
?>