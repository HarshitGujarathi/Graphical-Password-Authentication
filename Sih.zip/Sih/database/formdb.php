<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'test');

if(isset($_POST['Upload']))
{
    $username =$_POST['Username'];
   $file = addslashes(file_get_contents($_FILES["password"]["tmp_name"]));

    $query = "INSERT INTO 'images'('Username','Password')  VALUES ('$username','$file')";
    //$query_run = mysqli_query($connection,$query);
        if(mysqli_query($connection,$query))
        {
            echo '<script type="text/javascript"> alert("Image Uploaded") </script>';
        }
        else
        {
            echo '<script type="text/javascript"> alert("Image not  Uploaded") </script>';
        } 
}
?>




