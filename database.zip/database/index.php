<?php
//include 'upload.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
     
</head>
<body>
    <div class="container">
        <h1>Upload and store img in db</h1>
        <div class="wrapper">
            <?php if(!empty($statusMsg)){?> 
            <p class="status <?php echo $status; ?>"><?php echo $statusMsg;?></p>
             <?php 
            } ?>
            <form action="upload.php" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for "image">Select image file:</label>
                    <input type="file" name="image" class="form-control">
                </div>
                <input type="submit" name="submit" class="btn-primary" value="Upload">
            </form>
</div>
</div>  
</body>
</html>