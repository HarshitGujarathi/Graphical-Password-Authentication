<html>
<head></head>
<title></title>
<body>
<form action="upload.php"method="POST" enctype="multipart/form-data" >
<label>Username</label>
<input type="text" name=" Username" required/>     
<br><br>
<label>Password</label>
<input type="file" id="files" name="password" multiple required/><Br><br>
<input type="submit" name="Upload" value="Upload Image"/>
</form>
</body>
</html>

<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'test');

if(isset($_POST['Upload']))
{
    
    $username =$_POST['Username'];
   $file = addslashes(file_get_contents($_FILES["password"]["tmp_name"]));

    $query = "INSERT INTO 'images'('Username','Password')  VALUES (' $username','$file')";
    $query_run = mysqli_query($connection,$query);


if($query_run)
{
    echo '<script type="text/javascript"> alert("Image Uploaded") </script>';
}
else
{
    echo '<script type="text/javascript"> alert("Image not  Uploaded") </script>';
} 
}
?>




