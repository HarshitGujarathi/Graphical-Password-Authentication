<?php
include('vendor/autoload.php');
$implementation = new Jenssegers\ImageHash\Implementations\DifferenceHash;
$hasher = new Jenssegers\ImageHash\ImageHash($implementation);
$hash = $hasher->hash('eye.jpg');
var_dump($hash);
?>